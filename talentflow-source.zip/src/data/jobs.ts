import type { Job } from '../types';
import jobRecords from './jobs.json';

export const sampleJobs = jobRecords as Job[];
