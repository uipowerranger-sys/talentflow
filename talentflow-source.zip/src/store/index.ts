import { configureStore, createSlice, type PayloadAction } from '@reduxjs/toolkit';
type AuthState = { authenticated: boolean; name: string };
const authSlice = createSlice({
  name: 'auth',
  initialState: {
    authenticated: sessionStorage.getItem('talentflow-demo-session') === 'active',
    name: sessionStorage.getItem('talentflow-demo-name') || 'Jordan Davis'
  } as AuthState,
  reducers: {
    signIn(state, action: PayloadAction<string>) {
      state.authenticated = true;
      state.name = action.payload; sessionStorage.setItem('talentflow-demo-session', 'active');
      sessionStorage.setItem('talentflow-demo-name',
        action.payload);
    },
    signOut(state) {
      state.authenticated = false; sessionStorage.removeItem('talentflow-demo-session');
    },
  },
});
export const { signIn, signOut } = authSlice.actions;
export const store = configureStore({ reducer: { auth: authSlice.reducer } });
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
