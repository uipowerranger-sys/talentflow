import { useQuery } from '@tanstack/react-query';
import { sampleJobs } from '../../data/jobs';

export function useJobs() {
  return useQuery({ queryKey: ['jobs'], queryFn: async () => sampleJobs });
}
