import { useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { useJobs } from './useJobs';
import type { Job } from '../../types';
import type { AppDispatch, RootState } from '../../store';
import { signOut } from '../../store';
import { AppHeader } from '../../components/AppHeader';
import { JobCard } from '../../components/JobCard';
import { MatchDetails } from '../../components/MatchDetails';
import { ResumeUpload } from '../resume/ResumeUpload';
import { SkillsSection } from '../profile/SkillsSection';
import { t } from '../../i18n';
import filterOptions from '../../data/filters.json';

const categories = ['category.software', 'category.ui', 'category.backend', 'category.fullStack', 'category.data', 'category.devops'] as const;
const locations = ['location.bengaluru', 'location.dubai', 'location.hyderabad', 'location.remote', 'location.abudhabi'] as const;
const experiences = ['experience.2to4', 'experience.3to5', 'experience.4to6', 'experience.5to7', 'experience.5to8', 'experience.6to8'] as const;

export function JobSearchPage() {
  const dispatch = useDispatch<AppDispatch>(); const navigate = useNavigate();
  const name = useSelector((state: RootState) => state.auth.name);
  const { data: jobs = [] } = useJobs();
  const [query, setQuery] = useState(''); const [technology, setTechnology] = useState(''); const [category, setCategory] = useState(''); const [location, setLocation] = useState(''); const [experience, setExperience] = useState('');
  const [skills, setSkills] = useState(filterOptions.initialCandidateSkills);
  const [activeJob, setActiveJob] = useState<Job | null>(null); const [toast, setToast] = useState('');
  const [uploaded, setUploaded] = useState(localStorage.getItem('talentflow-resume-demo') === 'uploaded'); const [saved, setSaved] = useState<number[]>([]);
  const visibleJobs = useMemo(() => jobs.filter((job) => {
    const text = `${job.title} ${job.company} ${job.category} ${job.location} ${job.skills.join(' ')}`.toLowerCase();
    return (!query || text.includes(query.toLowerCase())) && (!technology || job.skills.includes(technology)) && (!category || job.category === category) && (!location || job.location === location) && (!experience || job.experience === experience);
  }), [jobs, query, technology, category, location, experience]);
  function notify(message: string) { setToast(message); window.setTimeout(() => setToast(''), 2800); }
  function logout() { dispatch(signOut()); navigate('/login', { replace: true }); }
  function addSkills(next: string[]) { setSkills((current) => Array.from(new Set([...current, ...next]))); notify(t('jobs.skillsUpdated')); }
  return <div className="app-page"><AppHeader name={name} onSignOut={logout} /><main className="page-shell">
    <section className="page-intro"><div><div className="eyebrow light-eyebrow">{t('jobs.eyebrow')}</div><h1>{t('jobs.title')} <span>{t('jobs.titleHighlight')}</span></h1><p>{t('jobs.subtitle')}</p></div><div className="live-note"><i className="fa-solid fa-circle" aria-hidden="true" /> 248 {t('jobs.newThisWeek')}</div></section>
    <div className="workspace-grid"><aside className="side-panel"><div className="side-kicker">{t('jobs.workspace')}</div><a className="side-link active" href="#jobs"><i className="fa-solid fa-magnifying-glass" aria-hidden="true" /> <span>{t('jobs.findOpportunities')}</span></a><a className="side-link" href="#jobs"><i className="fa-regular fa-bookmark" aria-hidden="true" /> <span>{t('jobs.savedJobs')}</span><b>{saved.length}</b></a><a className="side-link" href="#profile"><i className="fa-regular fa-user" aria-hidden="true" /> <span>{t('nav.myProfile')}</span></a><div className="side-promo"><small>{t('auth.story.registerEyebrow')}</small><h3>{t('auth.story.loginTitle')} {t('auth.story.loginHighlight')}</h3><p>{t('auth.story.copy')}</p><a href="#profile">{t('jobs.mySkills')}&nbsp; ↗</a></div></aside>
      <section className="jobs-column" id="jobs">{!uploaded ? <ResumeUpload onUploaded={() => { setUploaded(true); localStorage.setItem('talentflow-resume-demo', 'uploaded'); notify(t('jobs.resumeSuccess')); }} /> : <div className="resume-complete"><span><i className="fa-solid fa-check" aria-hidden="true" /></span><div><strong>{t('jobs.resumeCompleteTitle')}</strong><small>{t('jobs.resumeCompleteSubtitle')}</small></div></div>}
        <div className="filters-card"><label className="search-field"><span><i className="fa-solid fa-magnifying-glass" aria-hidden="true" /></span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t('jobs.searchPlaceholder')} aria-label={t('jobs.searchPlaceholder')} /></label><div className="filter-row"><select aria-label={t('jobs.filterTechnology')} value={technology} onChange={(event) => setTechnology(event.target.value)}><option value="">{t('jobs.filterTechnology')}</option>{filterOptions.technologies.map((item) => <option key={item}>{item}</option>)}</select><select aria-label={t('jobs.filterCategory')} value={category} onChange={(event) => setCategory(event.target.value)}><option value="">{t('jobs.filterCategory')}</option>{categories.map((key) => <option key={key} value={t(key)}>{t(key)}</option>)}</select><select aria-label={t('jobs.filterLocation')} value={location} onChange={(event) => setLocation(event.target.value)}><option value="">{t('jobs.filterLocation')}</option>{locations.map((key) => <option key={key} value={t(key)}>{t(key)}</option>)}</select><select aria-label={t('jobs.filterExperience')} value={experience} onChange={(event) => setExperience(event.target.value)}><option value="">{t('jobs.filterExperience')}</option>{experiences.map((key) => <option key={key} value={t(key)}>{t(key)}</option>)}</select></div></div>
        <div className="results-heading"><div><h2>{skills.length > 7 ? t('jobs.matched') : t('jobs.latest')} <span>({visibleJobs.length})</span></h2><p>{t('jobs.resultsSubtitle')}</p></div><span className="sort-label">{t('jobs.sortRelevant')}</span></div>
        <div className="job-list">{visibleJobs.length ? visibleJobs.map((job) => <JobCard key={job.job_id} job={job} saved={saved.includes(job.job_id)} onSave={() => setSaved((current) => current.includes(job.job_id) ? current.filter((id) => id !== job.job_id) : [...current, job.job_id])} onDetails={() => setActiveJob(job)} onApply={() => notify(t('jobs.applyReady'))} />) : <div className="empty-state"><strong>{t('jobs.emptyTitle')}</strong><p>{t('jobs.emptySubtitle')}</p><button className="button secondary" onClick={() => { setQuery(''); setTechnology(''); setCategory(''); setLocation(''); setExperience(''); }}>{t('jobs.clearFilters')}</button></div>}</div>
      </section><SkillsSection skills={skills} onRemove={(skill) => setSkills((current) => current.filter((item) => item !== skill))} onAdd={addSkills} />
    </div></main>{activeJob && <MatchDetails job={activeJob} onClose={() => setActiveJob(null)} onApply={() => { setActiveJob(null); notify(t('jobs.applyReady')); }} />}{toast && <div role="status" className="toast"><i className="fa-solid fa-circle-check" aria-hidden="true" />&nbsp; {toast}</div>}</div>;
}
