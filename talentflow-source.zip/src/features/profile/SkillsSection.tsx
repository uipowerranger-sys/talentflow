import { useState } from 'react';
import { t } from '../../i18n';
import filterOptions from '../../data/filters.json';
const choices = filterOptions.suggestedSkills;
export function SkillsSection({ skills, onRemove, onAdd }: { skills: string[]; onRemove: (skill: string) => void; onAdd: (skills: string[]) => void }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState<string[]>([]);
  const filtered = choices.filter((item) => !skills.includes(item) && item.toLowerCase().includes(query.toLowerCase()));

  return <aside className="profile-panel" id="profile">
    <div className="profile-heading">
      <h2>{t('jobs.profileTitle')}</h2><span>68%</span></div>
    <div className="profile-card">
      <div className="profile-avatar">TF</div>
      <div>
        <strong>{t('jobs.profileCandidate')}</strong>
        <small>{t('jobs.profileSubtitle')}</small>
      </div>
    </div>
    <div className="progress-copy"><span>{t('jobs.profileCompleteness')}</span><b>68%</b></div>
    <div className="progress-track"><i />
    </div>
    <hr />
    <div className="profile-heading">
      <h3>{t('jobs.mySkills')}</h3>
      <button className="text-link" onClick={() => setOpen(true)}><i className="fa-solid fa-plus" aria-hidden="true" /> {t('jobs.addSkill')}</button>
    </div>
    <p className="skills-help">{t('jobs.skillsSubtitle')}</p>
    <div className="profile-skills">{skills.map((skill) => <span className="editable-skill" key={skill}>{skill}
      <button aria-label={t('jobs.removeSkill', { skill })} onClick={() => onRemove(skill)}><i className="fa-solid fa-xmark" aria-hidden="true" /></button></span>)}
    </div>
    <div className="profile-tip">{t('jobs.skillsTip')}

    </div>
    {open && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => {
      if (event.target === event.currentTarget) setOpen(false);
    }}>
      <section className="detail-modal skill-modal" role="dialog" aria-modal="true" aria-labelledby="skills-title">
        <button className="modal-close" onClick={() => setOpen(false)} aria-label={t('jobs.close')}><i className="fa-solid fa-xmark" aria-hidden="true" /></button>
        <div className="form-eyebrow">{t('auth.story.registerEyebrow')}</div><h2 id="skills-title">{t('jobs.addSkillsTitle')}</h2>
        <p className="detail-meta">{t('jobs.addSkillsSubtitle')}</p>
        <input className="skill-search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t('jobs.searchSkills')} />
        <div className="suggestion-list">{filtered.map((item) => <button key={item} className={selected.includes(item) ? 'suggestion selected' : 'suggestion'} onClick={() => setSelected((current) => current.includes(item) ? current.filter((skill) => skill !== item) : [...current, item])}>{selected.includes(item) ? <i className="fa-solid fa-check" aria-hidden="true" /> : <i className="fa-solid fa-plus" aria-hidden="true" />} {item}</button>)}</div>
        <div className="modal-actions"><button className="button secondary" onClick={() => setOpen(false)}>{t('jobs.cancel')}</button>
          <button className="button" onClick={() => { onAdd(selected); setSelected([]); setQuery(''); setOpen(false); }}>{t('jobs.addSelectedSkills')}</button>
        </div>
      </section>
    </div>}
  </aside>;
}
