import { useRef, useState } from 'react';
import { t } from '../../i18n';
export function ResumeUpload({ onUploaded }: { onUploaded: () => void }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState('');
  const [working, setWorking] = useState(false);
  function chooseFile(candidate?: File) {
    if (!candidate) return;
    const ext = candidate.name.split('.').pop()?.toLowerCase();
    if (!['pdf', 'doc', 'docx'].includes(ext || '')) {
      setError(t('jobs.resumeFileTypes'));
      return;
    }
    if (candidate.size > 10 * 1024 * 1024) {
      setError(t('jobs.resumeTooLarge'));
      return;
    }
    setError(''); setFile(candidate);
  }
  function submit() {
    if (!file) { setError(t('jobs.resumeRequired')); return; }
    setWorking(true); window.setTimeout(() => {
      setWorking(false); setFile(null);
      onUploaded();
    }, 500);
  }
  return <section className="resume-banner">
    <div className="resume-symbol"><i className="fa-solid fa-cloud-arrow-up" aria-hidden="true" /></div>
    <div className="resume-copy">
      <strong>{t('jobs.resumeTitle')}</strong>
      <small>{t('jobs.resumeSubtitle')}</small>
      {file && <small className="selected-file">{file.name}</small>}
      {error && <small className="upload-error">{error}</small>}
    </div>
    <input ref={inputRef} type="file" accept=".pdf,.doc,.docx" hidden onChange={(event) => chooseFile(event.target.files?.[0])} />
    <button className="button" onClick={() => file ? submit() : inputRef.current?.click()} disabled={working}>{working ? t('jobs.resumeAdding') : file ? t('jobs.resumeAdd') : t('jobs.resumeChoose')}</button>
    {file && <button className="text-button" onClick={() => setFile(null)}>{t('jobs.cancel')}</button>}
    <span className="banner-demo-note">{t('jobs.resumeDemoOnly')}</span>
  </section>;
}
