import { useState, type FormEvent } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import type { AppDispatch } from '../../store';
import { signIn } from '../../store';
import { AuthLayout } from '../../components/AuthLayout';
import { t } from '../../i18n';

export function LoginPage() {
  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate();
  const [message, setMessage] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const email = String(data.get('email') || '');
    dispatch(signIn(email.split('@')[0] || 'Candidate'));
    navigate('/jobs', { replace: true });
  }
  return <AuthLayout><>{message && <div role="status" className="form-message">{message}</div>}
    <form className="auth-form" onSubmit={handleSubmit}>
      <label>{t('auth.login.email')}<input type="email" name="email" placeholder={t('auth.login.emailPlaceholder')} autoComplete="email" required />
      </label>
      <label>{t('auth.login.password')}<div className="password-field">
        <input type={showPassword ? 'text' : 'password'} name="password" placeholder={t('auth.login.passwordPlaceholder')} autoComplete="current-password" minLength={8} required /><button type="button" onClick={() => setShowPassword(!showPassword)}>{t(showPassword ? 'auth.login.hidePassword' : 'auth.login.showPassword')}</button>
      </div>
      </label>
      <div className="form-options">
        <label className="check-label">
          <input type="checkbox" name="remember" /> {t('auth.login.remember')}
        </label>
        <button type="button" className="text-link" onClick={() => setMessage(t('auth.login.forgotMessage'))}>{t('auth.login.forgot')}</button></div><button className="submit-button" type="submit">{t('auth.login.submit')}&nbsp; →</button>
    </form>
    <div className="auth-legal">{t('auth.login.demoNote')}</div></>
  </AuthLayout>;
}
