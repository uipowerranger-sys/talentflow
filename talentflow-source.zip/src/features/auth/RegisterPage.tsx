import { useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthLayout } from '../../components/AuthLayout';
import { t } from '../../i18n';

export function RegisterPage() {
  const navigate = useNavigate();
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    if (data.get('password') !== data.get('confirmPassword')) {
      setError(t('auth.register.passwordMismatch')); return;
    }
    navigate('/login', { replace: true });
  }
  return <AuthLayout register><>
    {error && <div role="alert" className="form-message">{error}</div>}
    <form className="auth-form compact-form" onSubmit={handleSubmit}>
      <div className="name-fields">
        <label>{t('auth.register.firstName')}<input name="firstName" placeholder={t('auth.register.firstNamePlaceholder')} autoComplete="given-name" required /></label>
        <label>{t('auth.register.lastName')}<input name="lastName" placeholder={t('auth.register.lastNamePlaceholder')} autoComplete="family-name" required /></label>
      </div>
      <label>{t('auth.login.email')}<input type="email" name="email" placeholder={t('auth.login.emailPlaceholder')} autoComplete="email" required />
      </label><label>{t('auth.register.password')}<div className="password-field"><input type={showPassword ? 'text' : 'password'} name="password" placeholder={t('auth.register.passwordPlaceholder')} autoComplete="new-password" minLength={8} required /><button type="button" onClick={() => setShowPassword(!showPassword)}>{t(showPassword ? 'auth.login.hidePassword' : 'auth.login.showPassword')}</button></div></label>
      <label>{t('auth.register.confirmPassword')}<input type="password" name="confirmPassword" placeholder={t('auth.register.confirmPlaceholder')} autoComplete="new-password" minLength={8} required /></label>
      <label className="check-label terms"><input type="checkbox" required />
        <span>{t('auth.register.terms')} <a href="#terms">{t('auth.register.termsLink')}</a> {t('auth.register.and')} <a href="#privacy">{t('auth.register.privacyLink')}</a>.</span>
      </label>
      <button className="submit-button" type="submit">{t('auth.register.submit')}&nbsp; →</button>
    </form>
    <div className="auth-legal">{t('auth.register.demoNote')}</div>
  </>
  </AuthLayout>;
}
